<?php
  include_once ('db_conn.php');

  /* Recuperamos los datos de texto del usuario. */
  $UserData = json_decode($_POST["User"], true);
  $id = $UserData["id"];
  $dni = $UserData["dni"];
  $nombre = $UserData["nombre"];
  $fecha_de_ingreso = $UserData["fecha_de_ingreso"];


  /* Se intenta actualizar el registro. Si el DNI está duplicado, 
  no se podrá efectuar la actualización de datos. */
  $numeroDeError = "0";

  $consulta = "UPDATE socios SET ";
  $consulta .= "dni = :dni, ";
  $consulta .= "nombre = :nombre, ";
  $consulta .= "fecha_de_ingreso = :fecha_de_ingreso ";
  $consulta .= "WHERE id = :id;";

  $hacerConsulta = $conexion->prepare($consulta); // Se crea un objeto PDOStatement.
  $hacerConsulta->bindParam(":id", $id); // Se asigna una variable para la consulta.
  $hacerConsulta->bindParam(":dni", $dni); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam(":nombre", $nombre); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam(":fecha_de_ingreso", $fecha_de_ingreso); // Se asigna un valor para la consulta.
  try {
    $hacerConsulta->execute(); // Se ejecuta la consulta.
  } catch (PDOException $e) {
    $numeroDeError = $hacerConsulta->errorCode();
  }
	$hacerConsulta->closeCursor(); // Se libera el recurso.

  /* Si se ha podido actualizar el registro, leemos el nombre del 
  avatar actual, si hay alguno, para sustituirlo.
  Si no se ha seleccionado avatar, se dejará el existente. */
  if ($numeroDeError == "0" && isset($_FILES["Avatar"])) {
    $consulta = "SELECT avatar FROM socios ";
    $consulta .= "WHERE id = '".$id."';";
    $hacerConsulta = $conexion->query($consulta);
    $avatarAlmacenado = $hacerConsulta->fetch(PDO::FETCH_ASSOC)["avatar"];
    $hacerConsulta->closeCursor();
    if (strpos($avatarAlmacenado, "sin_avatar") === false) {
      @unlink($avatarAlmacenado);
    }
    $nombreDeAvatar = "avatares/".md5(uniqid()).".jpg";
    $consulta = "UPDATE socios SET ";
    $consulta .= "avatar = '".$nombreDeAvatar."' ";
    $consulta .= "WHERE id = '".$id."';";
    $conexion->query($consulta);
    move_uploaded_file($_FILES["Avatar"]["tmp_name"], $nombreDeAvatar);
  }

  $respuesta = json_encode($numeroDeError);
  echo $respuesta;
?>
