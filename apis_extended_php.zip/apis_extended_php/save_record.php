<?php
  include_once ('db_conn.php');

  /* Recuperamos los datos de texto del usuario. */
  $UserData = json_decode($_POST["User"], true);

  // Generamos un ID para el usuario.
  $id = md5(uniqid());

  // Si hay un fichero, generamos un nombre para el fichero.
  if (isset($_FILES["Avatar"])) {
    $nombreDeAvatar = "avatares/".md5(uniqid()).".jpg";
  } else {
    $nombreDeAvatar = "avatares/sin_avatar.jpg";
  }
  
  /* Tratamos de grabar el registro del usuario. Si el DNI está repetido, fallará. */
  $numeroDeError = "0";

  $consulta = "INSERT INTO socios (";
  $consulta .= "id, dni, nombre, fecha_de_ingreso, avatar";
  $consulta .= ") VALUES (";
  $consulta .= ":id, :dni, :nombre, :fecha_de_ingreso, :avatar);";

  $numeroDeError = "0";
  $hacerConsulta = $conexion->prepare($consulta); // Se crea un objeto PDOStatement.
  $hacerConsulta->bindParam("id", $id); // Se asigna una variable para la consulta.
  $hacerConsulta->bindParam("dni", $UserData['dni']); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam("nombre", $UserData['nombre']); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam("fecha_de_ingreso", $UserData['fecha_de_ingreso']); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam("avatar", $nombreDeAvatar); // Se asigna un valor para la consulta.
  try {
    $hacerConsulta->execute(); // Se ejecuta la consulta.
  } catch (PDOException $e) {
    $numeroDeError = $hacerConsulta->errorCode();
  }
  $hacerConsulta->closeCursor(); // Se libera el recurso.
  
  /* Si se ha podido grabar el registro, se graba el avatar. */
  if ($numeroDeError == "0" && isset($_FILES["Avatar"])) {
    move_uploaded_file($_FILES["Avatar"]["tmp_name"], $nombreDeAvatar);
  }

  $respuesta = json_encode($numeroDeError);
  echo $respuesta;
?>
